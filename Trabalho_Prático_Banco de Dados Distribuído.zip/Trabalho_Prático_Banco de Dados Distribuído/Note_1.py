# Databricks notebook source
display(dbutils.fs.ls("/databricks-datasets"))

# COMMAND ----------

arquivo ="dbfs:/databricks-datasets/flights/"

# COMMAND ----------

arquivo

# COMMAND ----------

df = spark \
    .read.format("csv") \
    .option("inferSchema", "True")\
    .csv(arquivo)

# COMMAND ----------

df.printSchema()

# COMMAND ----------

type(df)

# COMMAND ----------

df.take(5)

# COMMAND ----------

display(df.show(5))

# COMMAND ----------

df.count()

# COMMAND ----------

from pyspark.sql.functions import max
df.select(max("_c2")).take(2)

# COMMAND ----------

df.filter("_c1 < 2").show(2)

# COMMAND ----------

df.where("_c1 < 5").show(100)

# COMMAND ----------

df.sort("_c1").show(5)

# COMMAND ----------

df.orderBy(expr("_c1 desc")).show(10)

# COMMAND ----------

df.describe().show()

# COMMAND ----------

df.filter(df_c1.isNull()).show(10)
df.na.fill(value=0)
